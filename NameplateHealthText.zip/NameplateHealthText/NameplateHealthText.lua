local Frame = CreateFrame("Frame")
Frame:RegisterEvent("PLAYER_TARGET_CHANGED")
Frame:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
Frame:RegisterEvent("UNIT_HEALTH")

local PlacasRegistradas = {}
local MemoriaVidaMonstruos = {}

if not NameplateHealthTextDB then
    NameplateHealthTextDB = { offset = 0 }
end
local DB = NameplateHealthTextDB

local function FormatearVida(valor)
    if not valor or valor <= 0 then return "0" end
    if valor >= 1000000 then
        return string.format("%.1fM", valor / 1000000)
    elseif valor >= 1000 then
        return string.format("%.1fk", valor / 1000)
    else
        return tostring(valor)
    end
end

local function RegistrarUnidad(unit)
    if not UnitExists(unit) then return end
    local maxVida = UnitHealthMax(unit) or 0
    if maxVida > 100 then
        MemoriaVidaMonstruos[maxVida] = maxVida
    end
end

local function ActualizarVidaRealDeLaPlaca(placa, barra, textoDestino)
    if not barra or not textoDestino then return end
    
    local valorBarra = barra:GetValue() or 0
    local _, maxBarra = barra:GetMinMaxValues()
    if maxBarra <= 0 then return end

    local porcentaje = math.floor((valorBarra / maxBarra) * 100)
    if valorBarra <= 0 or porcentaje <= 0 or porcentaje > 100 then
        textoDestino:SetText("")
        return
    end

    local saludObjetivoMax = UnitExists("target") and UnitHealthMax("target") or 0
    
    if saludObjetivoMax > 100 and UnitExists("target") and (math.abs(porcentaje - math.floor((UnitHealth("target")/saludObjetivoMax)*100)) <= 2) then
        local vidaActualReal = UnitHealth("target")
        textoDestino:SetText(string.format("%s / %s", FormatearVida(vidaActualReal), FormatearVida(saludObjetivoMax)))
    else
        local vidaMaximaEstimada = MemoriaVidaMonstruos[saludObjetivoMax] or (saludObjetivoMax > 100 and saludObjetivoMax or nil)
        if vidaMaximaEstimada then
            local vidaActualEstimada = math.floor((porcentaje / 100) * vidaMaximaEstimada)
            textoDestino:SetText(string.format("%s / %s", FormatearVida(vidaActualEstimada), FormatearVida(vidaMaximaEstimada)))
        else
            textoDestino:SetText(string.format("%d%%", porcentaje))
        end
    end
end

local function InyectarTextoExterno(placa, barraVida)
    if not barraVida then return end

    if not placa.miContenedorTexto then
        local contenedorTexto = CreateFrame("Frame", nil, placa)
        contenedorTexto:SetSize(140, 20)
        contenedorTexto:SetPoint("CENTER", barraVida, "CENTER", 0, DB.offset)
        contenedorTexto:SetFrameStrata("TOOLTIP")
        contenedorTexto:SetFrameLevel(placa:GetFrameLevel() + 30)

        local txt = contenedorTexto:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        txt:SetFont("Fonts\\FRIZQT__.TTF", 10, "THICKOUTLINE")
        txt:SetAllPoints(contenedorTexto)
        txt:SetTextColor(1, 1, 1, 1)

        placa.miContenedorTexto = contenedorTexto
        placa.miTextoFlotante = txt

        barraVida:HookScript("OnValueChanged", function(self)
            ActualizarVidaRealDeLaPlaca(placa, self, placa.miTextoFlotante)
        end)
    else
        placa.miContenedorTexto:SetPoint("CENTER", barraVida, "CENTER", 0, DB.offset)
    end

    ActualizarVidaRealDeLaPlaca(placa, barraVida, placa.miTextoFlotante)
end

-- ESCÁNER OPTIMIZADO: Ejecución controlada por tiempo para evitar caídas de FPS
local numHijosAnterior = 0
local tiempoAcumulado = 0

Frame:SetScript("OnUpdate", function(self, elapsed)
    tiempoAcumulado = tiempoAcumulado + elapsed
    
    -- El escáner pesado solo se ejecutará 5 veces por segundo (cada 0.2s), liberando al procesador
    if tiempoAcumulado >= 0.2 then
        tiempoAcumulado = 0
        local numHijos = WorldFrame:GetNumChildren()
        
        if numHijos ~= numHijosAnterior then
            numHijosAnterior = numHijos
            
            local hijos = { WorldFrame:GetChildren() }
            for _, child in ipairs(hijos) do
                if not child:GetName() and not PlacasRegistradas[child] then
                    local numSubHijos = child:GetNumChildren() or 0
                    if numSubHijos > 0 then
                        for i = 1, numSubHijos do
                            local subChild = select(i, child:GetChildren())
                            if subChild and subChild:GetObjectType() == "StatusBar" then
                                PlacasRegistradas[child] = subChild
                                
                                child:HookScript("OnShow", function(self)
                                    InyectarTextoExterno(self, PlacasRegistradas[self])
                                end)
                                
                                InyectarTextoExterno(child, subChild)
                                break
                            end
                        end
                    end
                end
            end
        end
    end
end)

Frame:SetScript("OnEvent", function(self, event, unit)
    if event == "PLAYER_TARGET_CHANGED" or event == "UPDATE_MOUSEOVER_UNIT" then
        RegistrarUnidad("target")
        RegistrarUnidad("mouseover")
    elseif event == "UNIT_HEALTH" and unit then
        RegistrarUnidad(unit)
    end
    
    for placa, barra in pairs(PlacasRegistradas) do
        if placa:IsShown() then ActualizarVidaRealDeLaPlaca(placa, barra, placa.miTextoFlotante) end
    end
end)

local function CreateHeightConfigButton()
    local btn = CreateFrame("Button", "NameplateHealthConfigButton", UIParent)
    btn:SetSize(40, 40)
    btn:SetPoint("CENTER", UIParent, "CENTER", 150, -50)
    btn:SetFrameStrata("MEDIUM")
    
    btn:SetMovable(true)
    btn:EnableMouse(true)
    btn:RegisterForDrag("LeftButton")
    btn:SetScript("OnDragStart", function(self) self:StartMoving() end)
    btn:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)

    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-Quickslot2")
    border:SetSize(64, 64)
    border:SetPoint("CENTER", btn, "CENTER", 0, 0)

    local icon = btn:CreateTexture(nil, "BACKGROUND")
    icon:SetTexture("Interface\\Icons\\Trade_Engineering")
    icon:SetSize(34, 34)
    icon:SetPoint("CENTER", btn, "CENTER", 0, 0)

    btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    btn:SetScript("OnClick", function(self, button)
        if button == "LeftButton" then
            DB.offset = DB.offset + 1
            print("|cff00ff00[Placas]|r Altura ajustada: +" .. DB.offset .. " px.")
        elseif button == "RightButton" then
            DB.offset = DB.offset - 1
            print("|cffff0000[Placas]|r Altura ajustada: " .. DB.offset .. " px.")
        end
        
        for placa, barra in pairs(PlacasRegistradas) do
            if placa:IsShown() then InyectarTextoExterno(placa, barra) end
        end
    end)
end

local InitFrame = CreateFrame("Frame")
InitFrame:RegisterEvent("ADDON_LOADED")
InitFrame:SetScript("OnEvent", function(self, event, addon)
    if addon == "NameplateHealthText" then CreateHeightConfigButton() end
end)
